// src/pages/dashboard/Subscription.tsx
import { useState } from 'react';

const plans = [
  {
    id: 'daily',
    name: 'Daily Pass',
    price: '$5/day',
    features: ['24-hr access', '1 vehicle', 'Basic support'],
  },
  {
    id: 'weekly',
    name: 'Weekly Pass',
    price: '$25/week',
    features: ['Unlimited access', '1 vehicle', 'Priority support'],
  },
  {
    id: 'monthly',
    name: 'Monthly Pass',
    price: '$80/month',
    features: ['Unlimited access', 'Multiple vehicles', '24/7 support'],
  },
];

const Subscription = () => {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const handleSubscribe = (planId: string) => {
    setSelectedPlan(planId);
    alert(`Subscribed to ${planId} successfully!`);
    // You can replace this with a POST request to your API
  };

  return (
    <div className="min-h-screen px-4 py-10 bg-gray-100">
      <h1 className="mb-8 text-3xl font-bold text-center">Choose a Subscription Plan</h1>

      <div className="grid max-w-5xl grid-cols-1 gap-6 mx-auto sm:grid-cols-2 lg:grid-cols-3">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={`bg-white rounded-2xl shadow-md p-6 border-2 ${
              selectedPlan === plan.id ? 'border-blue-500' : 'border-transparent'
            } transition-all duration-300 hover:shadow-xl`}
          >
            <h2 className="mb-2 text-xl font-semibold">{plan.name}</h2>
            <p className="mb-4 text-2xl font-bold text-blue-600">{plan.price}</p>
            <ul className="mb-4 space-y-1 text-sm text-gray-600">
              {plan.features.map((feature, i) => (
                <li key={i}>• {feature}</li>
              ))}
            </ul>
            <button
              onClick={() => handleSubscribe(plan.id)}
              className="w-full py-2 text-white transition bg-blue-600 rounded-xl hover:bg-blue-700"
            >
              {selectedPlan === plan.id ? 'Subscribed' : 'Subscribe Now'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Subscription;
