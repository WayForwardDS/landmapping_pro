// src/pages/dashboard/Facilities.tsx
import DashboardLayout from "../../components/DashboardLayout";
import { Plus } from "lucide-react";

const dummyFacilities = [
  { id: 1, name: "Main Street Lot", capacity: 50, status: "Active" },
  { id: 2, name: "Downtown Garage", capacity: 120, status: "Inactive" },
  { id: 3, name: "West Side Plaza", capacity: 90, status: "Active" },
];

const Facilities = () => {
  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-semibold">Facilities</h1>
        <button className="flex items-center gap-2 px-4 py-2 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700">
          <Plus className="w-4 h-4" />
          Add New Facility
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200 rounded-lg shadow-sm">
          <thead>
            <tr className="text-sm font-semibold text-left text-gray-600 bg-gray-100">
              <th className="p-4 border-b">Facility Name</th>
              <th className="p-4 border-b">Capacity</th>
              <th className="p-4 border-b">Status</th>
              <th className="p-4 border-b">Actions</th>
            </tr>
          </thead>
          <tbody>
            {dummyFacilities.map((facility) => (
              <tr key={facility.id} className="text-sm border-t hover:bg-gray-50">
                <td className="p-4">{facility.name}</td>
                <td className="p-4">{facility.capacity}</td>
                <td className="p-4">
                  <span
                    className={`px-2 py-1 text-xs rounded-full font-medium ${
                      facility.status === "Active"
                        ? "bg-green-100 text-green-600"
                        : "bg-red-100 text-red-600"
                    }`}
                  >
                    {facility.status}
                  </span>
                </td>
                <td className="p-4">
                  <button className="mr-4 text-blue-600 hover:underline">Edit</button>
                  <button className="text-red-600 hover:underline">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
};

export default Facilities;
