import {
  GoogleMap,
  LoadScript,
  Polygon,
  InfoWindow,
} from '@react-google-maps/api';
import { useState } from 'react';

const containerStyle = {
  width: '100%',
  height: '100vh',
};

const center = {
  lat: 37.7749,
  lng: -122.4194,
};

// Define the type for each parking slot
type Slot = {
  id: string;
  name: string;
  position: { lat: number; lng: number }[];
  status: 'available' | 'occupied';
};

// Dummy slots data
const slots: Slot[] = [
  {
    id: '1',
    name: 'Slot A1',
    position: [
      { lat: 37.775, lng: -122.419 },
      { lat: 37.775, lng: -122.4185 },
      { lat: 37.7745, lng: -122.4185 },
      { lat: 37.7745, lng: -122.419 },
    ],
    status: 'available',
  },
  {
    id: '2',
    name: 'Slot A2',
    position: [
      { lat: 37.7745, lng: -122.4184 },
      { lat: 37.7745, lng: -122.4180 },
      { lat: 37.7740, lng: -122.4180 },
      { lat: 37.7740, lng: -122.4184 },
    ],
    status: 'occupied',
  },
];

export default function LiveParking() {
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [mapInstance, setMapInstance] = useState<google.maps.Map | null>(null);

  return (
    <LoadScript googleMapsApiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY}>
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        zoom={18}
        onLoad={(map: google.maps.Map) => setMapInstance(map)}
      >
        {slots.map((slot) => (
          <Polygon
            key={slot.id}
            paths={slot.position}
            options={{
              fillColor: slot.status === 'available' ? 'green' : 'red',
              fillOpacity: 0.6,
              strokeColor: slot.status === 'available' ? 'green' : 'red',
              strokeOpacity: 0.9,
              strokeWeight: 2,
            }}
            onClick={() => setSelectedSlot(slot)}
          />
        ))}

        {selectedSlot && (
          <InfoWindow
            position={selectedSlot.position[0]}
            onCloseClick={() => setSelectedSlot(null)}
          >
            <div>
              <h2>{selectedSlot.name}</h2>
              <p>Status: {selectedSlot.status}</p>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    </LoadScript>
  );
}
