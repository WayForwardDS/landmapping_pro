import DashboardLayout from "../../components/DashboardLayout";
import ImageUploader from "../../components/forms/ImageUploader";
import { useState } from "react";

const AddSpace = () => {
  const [space, setSpace] = useState({
    name: "",
    location: "",
    price: "",
    size: "",
    facilities: [] as string[],
    image: null as File | null,
  });

  const facilityOptions = ["CCTV", "EV Charging", "Wi-Fi", "Security", "Covered", "24/7 Access"];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSpace({ ...space, [e.target.name]: e.target.value });
  };

  const toggleFacility = (facility: string) => {
    setSpace((prev) => ({
      ...prev,
      facilities: prev.facilities.includes(facility)
        ? prev.facilities.filter((f) => f !== facility)
        : [...prev.facilities, facility],
    }));
  };

  const handleImageUpload = (file: File) => {
    setSpace((prev) => ({ ...prev, image: file }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Submitted space:", space);
    // TODO: Send `space` data + image to backend via FormData
  };

  return (
    <DashboardLayout>
      <h1 className="text-xl font-semibold mb-6">Add New Parking Space</h1>

      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-xl shadow p-6 space-y-4 max-w-3xl"
      >
        <input
          name="name"
          value={space.name}
          onChange={handleChange}
          placeholder="Space Name"
          className="w-full border p-3 rounded"
        />
        <input
          name="location"
          value={space.location}
          onChange={handleChange}
          placeholder="Location"
          className="w-full border p-3 rounded"
        />
        <input
          name="price"
          value={space.price}
          onChange={handleChange}
          placeholder="Price per Hour"
          className="w-full border p-3 rounded"
        />
        <input
          name="size"
          value={space.size}
          onChange={handleChange}
          placeholder="Space Size (e.g., 20x10)"
          className="w-full border p-3 rounded"
        />

        <div>
          <p className="font-medium mb-2">Facilities</p>
          <div className="flex flex-wrap gap-2">
            {facilityOptions.map((fac) => (
              <button
                type="button"
                key={fac}
                onClick={() => toggleFacility(fac)}
                className={`px-3 py-1 border rounded-full text-sm ${
                  space.facilities.includes(fac)
                    ? "bg-blue-500 text-white"
                    : "bg-gray-100 text-gray-700"
                }`}
              >
                {fac}
              </button>
            ))}
          </div>
        </div>

        {/* 📸 Image Uploader */}
        <div>
          <p className="font-medium mb-2">Upload Space Image</p>
          <ImageUploader onUpload={handleImageUpload} />
        </div>

        <button
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded"
        >
          Save Space
        </button>
      </form>
    </DashboardLayout>
  );
};

export default AddSpace;
