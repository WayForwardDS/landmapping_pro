import DashboardLayout from "../../components/DashboardLayout";
import StatCard from "../../components/dashboard/StatCard";
import {
  Users,
  FileText,
  ShoppingCart,
  BarChart2,
} from "lucide-react";

const Dashboard = () => {
  return (
    <DashboardLayout>
      <h1 className="text-xl font-semibold mb-6">Dashboard Overview</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          icon={<Users className="text-blue-500" />}
          value="1,248"
          label="Active Users"
          className="border-blue-500"
        />
        <StatCard
          icon={<FileText className="text-green-500" />}
          value="326"
          label="Reports Generated"
          className="border-green-500"
        />
        <StatCard
          icon={<ShoppingCart className="text-yellow-500" />}
          value="984"
          label="New Orders"
          className="border-yellow-500"
        />
        <StatCard
          icon={<BarChart2 className="text-red-500" />}
          value="87%"
          label="Goal Progress"
          className="border-red-500"
        />
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;
