// src/pages/dashboard/Scanner.tsx
import { useEffect, useRef, useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';

const Scanner = () => {
  const [scanResult, setScanResult] = useState<string>('No result detected');
  const [error, setError] = useState<string | null>(null);
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    // Initialize scanner
    const scanner = new Html5QrcodeScanner(
      'qr-reader', 
      {
        qrbox: { width: 250, height: 250 },
        fps: 10,
        supportedScanTypes: [0, 1] // 0 = QR code, 1 = barcode
      },
      false
    );

    const successCallback = (decodedText: string) => {
      setScanResult(decodedText);
      setError(null);
      scanner.clear();
      scannerRef.current = null;
    };

    const errorCallback = (err: string) => {
      setError(err);
    };

    scanner.render(successCallback, errorCallback);
    scannerRef.current = scanner;

    // Cleanup
    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear();
      }
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
      <h1 className="mb-6 text-3xl font-bold text-gray-800">Parking Slot Scanner</h1>
      
      {/* Scanner Container */}
      <div className="relative w-full max-w-md mb-6 aspect-square">
        <div 
          id="qr-reader"
          className="w-full h-full overflow-hidden border-4 border-blue-500 shadow-lg rounded-xl"
        ></div>
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-64 h-64 border-2 border-white border-dashed rounded-lg"></div>
        </div>
      </div>

      {/* Scan Results */}
      <div className="w-full max-w-md p-6 bg-white shadow-md rounded-xl">
        <h2 className="mb-3 text-xl font-semibold text-gray-700">Scan Result:</h2>
        <div className="p-4 mb-4 bg-gray-100 rounded-lg">
          <p className="font-mono text-green-600 break-all">{scanResult}</p>
        </div>
        
        {error && (
          <div className="p-3 bg-red-100 rounded-lg">
            <p className="text-red-600">Error: {error}</p>
          </div>
        )}

        {/* Manual Input Fallback */}
        <div className="mt-6">
          <label className="block mb-2 text-sm font-medium text-gray-700">
            Or enter manually:
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter slot number"
            />
            <button className="px-4 py-2 text-white transition bg-blue-600 rounded-lg hover:bg-blue-700">
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Scanner;