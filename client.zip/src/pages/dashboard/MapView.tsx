// import { GoogleMap, LoadScript, Polygon, Marker, InfoWindow } from '@react-google-maps/api';
// import { useState } from 'react';

// const MONROVIA_BOUNDS = {
//   north: 6.35,
//   south: 6.25,
//   west: -10.85,
//   east: -10.75
// };

// const containerStyle = {
//   width: '100%',
//   height: 'calc(100vh - 64px)',
// };

// const center = {
//   lat: 6.3106,
//   lng: -10.8047
// };

// const MONROVIA_PARKING_ZONES = [
//   {
//     id: 'P1',
//     name: 'Central Monrovia Parking',
//     position: [
//       { lat: 6.3109, lng: -10.8046 },
//       { lat: 6.3109, lng: -10.8038 },
//       { lat: 6.3102, lng: -10.8038 },
//       { lat: 6.3102, lng: -10.8046 }
//     ],
//     status: 'available',
//     rate: 'LD 500/hour',
//     capacity: 120
//   },
//   {
//     id: 'P2',
//     name: 'Sinkor Commercial Parking',
//     position: [
//       { lat: 6.3130, lng: -10.8015 },
//       { lat: 6.3130, lng: -10.8005 },
//       { lat: 6.3120, lng: -10.8005 },
//       { lat: 6.3120, lng: -10.8015 }
//     ],
//     status: 'full',
//     rate: 'LD 300/hour',
//     capacity: 80
//   },
//   {
//     id: 'P3',
//     name: 'Mamba Point Parking',
//     position: [
//       { lat: 6.3080, lng: -10.8080 },
//       { lat: 6.3080, lng: -10.8070 },
//       { lat: 6.3070, lng: -10.8070 },
//       { lat: 6.3070, lng: -10.8080 }
//     ],
//     status: 'partial',
//     rate: 'LD 700/hour',
//     capacity: 50
//   }
// ];

// const getZoneStyle = (status: string) => ({
//   fillColor: 
//     status === 'available' ? '#2ecc71' : 
//     status === 'partial' ? '#f39c12' : '#e74c3c',
//   fillOpacity: 0.6,
//   strokeColor: '#3498db',
//   strokeWeight: 2,
//   zIndex: 1
// });

// const MapView = () => {
//   const [selectedZone, setSelectedZone] = useState<any>(null);
//   const [map, setMap] = useState<any>(null);

//   const onLoad = (mapInstance: any) => {
//     setMap(mapInstance);
//     mapInstance.fitBounds(MONROVIA_BOUNDS);
//     mapInstance.setOptions({
//       minZoom: 12,
//       restriction: {
//         latLngBounds: MONROVIA_BOUNDS,
//         strictBounds: true
//       }
//     });
//   };

//   const getCenter = (paths: any[]) => {
//     if (!window.google) return { lat: 0, lng: 0 };
//     const bounds = new window.google.maps.LatLngBounds();
//     paths.forEach(path => bounds.extend(path));
//     return bounds.getCenter();
//   };

//   return (
//     <LoadScript 
//       googleMapsApiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY}
//       libraries={['geometry']}
//     >
//       <div className="relative">
//         <GoogleMap
//           mapContainerStyle={containerStyle}
//           center={center}
//           zoom={14}
//           onLoad={onLoad}
//           options={{
//             streetViewControl: false,
//             mapTypeControl: false,
//             styles: [
//               {
//                 featureType: "poi",
//                 elementType: "labels",
//                 stylers: [{ visibility: "off" }]
//               }
//             ]
//           }}
//         >
//           {MONROVIA_PARKING_ZONES.map((zone) => {
//             const centerPos = getCenter(zone.position);
//             return (
//               <div key={zone.id}>
//                 <Polygon
//                   paths={zone.position}
//                   options={getZoneStyle(zone.status)}
//                   onClick={() => setSelectedZone(zone)}
//                 />
//                 <Marker
//                   position={centerPos}
//                   icon={{
//                     path: window.google?.maps.SymbolPath.CIRCLE || 0,
//                     scale: 7,
//                     fillColor: getZoneStyle(zone.status).fillColor,
//                     fillOpacity: 1,
//                     strokeWeight: 2,
//                     strokeColor: 'white'
//                   }}
//                   onClick={() => setSelectedZone(zone)}
//                 />
//               </div>
//             );
//           })}

//           {selectedZone && (
//             <InfoWindow
//               position={getCenter(selectedZone.position)}
//               onCloseClick={() => setSelectedZone(null)}
//             >
//               <div className="space-y-1">
//                 <h3 className="font-bold text-blue-800">{selectedZone.name}</h3>
//                 <p>
//                   Status: <span className="font-medium capitalize" style={{
//                     color: getZoneStyle(selectedZone.status).fillColor
//                   }}>
//                     {selectedZone.status}
//                   </span>
//                 </p>
//                 <p>Rate: {selectedZone.rate}</p>
//                 <p>Capacity: {selectedZone.capacity} vehicles</p>
//                 <button 
//                   className="px-3 py-1 mt-2 text-sm text-white bg-blue-600 rounded hover:bg-blue-700"
//                   onClick={() => alert(`Reserving ${selectedZone.name}`)}
//                 >
//                   Reserve Space
//                 </button>
//               </div>
//             </InfoWindow>
//           )}
//         </GoogleMap>

//         <div className="absolute z-10 p-3 space-y-2 text-sm bg-white rounded-lg shadow-lg top-4 left-4">
//           <h4 className="pb-1 font-bold text-gray-800 border-b">Monrovia Parking Status</h4>
//           <div className="flex items-center space-x-2">
//             <div className="w-4 h-4 bg-green-500 rounded-sm" />
//             <span>Available ({MONROVIA_PARKING_ZONES.filter(z => z.status === 'available').length})</span>
//           </div>
//           <div className="flex items-center space-x-2">
//             <div className="w-4 h-4 bg-yellow-500 rounded-sm" />
//             <span>Partial ({MONROVIA_PARKING_ZONES.filter(z => z.status === 'partial').length})</span>
//           </div>
//           <div className="flex items-center space-x-2">
//             <div className="w-4 h-4 bg-red-500 rounded-sm" />
//             <span>Full ({MONROVIA_PARKING_ZONES.filter(z => z.status === 'full').length})</span>
//           </div>
//         </div>
//       </div>
//     </LoadScript>
//   );
// };

// export default MapView;
import { useEffect, useState, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Configure Leaflet
const createParkingIcon = () => {
  return new L.Icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });
};

const ParkingMap = () => {
  const [parkingLocations, setParkingLocations] = useState<Array<[number, number]>>([]);
  const mapRef = useRef<L.Map | null>(null);
  const markerGroupRef = useRef<L.LayerGroup | null>(null);

  // Initialize map
  useEffect(() => {
    const map = L.map('map-container').setView([6.3106, -10.8047], 15);
    mapRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    markerGroupRef.current = L.layerGroup().addTo(map);

    // Click handler for adding markers
    map.on('click', (e: L.LeafletMouseEvent) => {
      const newLocation: [number, number] = [e.latlng.lat, e.latlng.lng];
      setParkingLocations(prev => [...prev, newLocation]);
    });

    return () => {
      map.remove();
    };
  }, []);

  // Update markers when locations change
  useEffect(() => {
    if (markerGroupRef.current) {
      markerGroupRef.current.clearLayers();
      
      parkingLocations.forEach(coords => {
        L.marker(coords, { icon: createParkingIcon() })
          .addTo(markerGroupRef.current!)
          .bindPopup(`
            <div class="p-2">
              <p>Parking Spot</p>
              <small>${coords[0].toFixed(5)}, ${coords[1].toFixed(5)}</small>
            </div>
          `);
      });
    }
  }, [parkingLocations]);

  const clearMarkers = () => {
    setParkingLocations([]);
  };

  return (
    <div className="relative w-full h-screen">
      <div id="map-container" className="w-full h-full" />
      
      {/* Control Panel */}
      <div className="absolute top-4 left-4 z-[1000] bg-white p-4 rounded-lg shadow-md space-y-3">
        <h3 className="font-bold">Parking Marker Tool</h3>
        
        <div className="flex gap-2">
          <button 
            onClick={clearMarkers}
            className="px-3 py-1 text-white bg-red-500 rounded hover:bg-red-600"
          >
            Clear All Markers
          </button>
        </div>

        <div className="text-sm">
          <p className="text-gray-600">Click anywhere on the map to place a red parking marker</p>
          <p className="text-gray-600">Markers placed: {parkingLocations.length}</p>
        </div>
      </div>
    </div>
  );
};

export default ParkingMap;