import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';
// import { Logo } from '../../components/Logo';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Send password reset request
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-6 rounded-2xl w-full max-w-md shadow-md">
        {/* <div className="flex justify-center mb-4">
          <Logo />
        </div> */}
        <h2 className="text-xl font-semibold text-center mb-4">Forgot Password</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Email"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
          />
          <Button type="submit" label="Send Reset Link" />
        </form>
        <p className="text-sm text-center mt-4">
          Remember your password? <Link to="/signin" className="text-blue-600 font-medium">Sign in</Link>
        </p>
      </div>
    </div>
  );
};

export default ForgotPassword;
