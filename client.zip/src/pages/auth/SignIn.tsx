import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';
// import { Logo } from '../../components/Logo';

const SignIn = () => {
  const [form, setForm] = useState({ email: '', password: '' });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Add API login logic
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-6 rounded-2xl w-full max-w-md shadow-md">
        {/* <div className="flex justify-center mb-4">
          <Logo />
        </div> */}
        <h2 className="text-xl font-semibold text-center mb-4">Sign In</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input label="Email" name="email" value={form.email} onChange={handleChange} type="email" />
          <Input label="Password" name="password" value={form.password} onChange={handleChange} type="password" />
          <Button type="submit" label="Sign In" />
        </form>
        <div className="text-sm flex justify-between mt-4">
          <Link to="/signup" className="text-blue-600 font-medium">Sign up</Link>
          <Link to="/forgot-password" className="text-blue-600 font-medium">Forgot Password?</Link>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
