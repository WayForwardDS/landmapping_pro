import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Input } from '../../components/Input';
import { Button } from '../../components/Button';
// import { Logo } from '../../components/Logo';

const SignUp = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-md p-6 bg-white shadow-md rounded-2xl">
        {/* <div className="flex justify-center mb-4">
          <Logo />
        </div> */}
        <h2 className="mb-4 text-xl font-semibold text-center">Sign Up</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input label="Name" name="name" value={form.name} onChange={handleChange} />
          <Input label="Email" name="email" value={form.email} onChange={handleChange} type="email" />
          <Input label="Password" name="password" value={form.password} onChange={handleChange} type="password" />
          <Input label="Confirm Password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} type="password" />
          <Button type="submit" label="Sign Up" />
        </form>
        <p className="mt-4 text-sm text-center">
          Already have an account? <Link to="/signin" className="font-medium text-blue-600">Sign in</Link>
        </p>
      </div>
    </div>
  );
};

export default SignUp;
