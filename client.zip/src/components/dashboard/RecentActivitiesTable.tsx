interface Activity {
  id: string;
  user: string;
  action: string;
  date: string;
  status: "Completed" | "Pending" | "Failed";
}

const dummyData: Activity[] = [
  { id: "TXN001", user: "John Doe", action: "Booked Slot A-12", date: "2025-05-16", status: "Completed" },
  { id: "TXN002", user: "Jane Smith", action: "Payment for Subscription", date: "2025-05-15", status: "Pending" },
  { id: "TXN003", user: "Mark Lee", action: "Cancelled Slot B-09", date: "2025-05-15", status: "Failed" },
];

const RecentActivitiesTable = () => {
  return (
    <div className="mt-10 bg-white rounded-xl shadow p-5">
      <h2 className="text-lg font-semibold mb-4">Recent Activities</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-700">
          <thead className="bg-gray-100 text-gray-600 uppercase text-xs">
            <tr>
              <th className="px-4 py-3">ID</th>
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">Action</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {dummyData.map((activity) => (
              <tr key={activity.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-3">{activity.id}</td>
                <td className="px-4 py-3">{activity.user}</td>
                <td className="px-4 py-3">{activity.action}</td>
                <td className="px-4 py-3">{activity.date}</td>
                <td className="px-4 py-3">
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      activity.status === "Completed"
                        ? "bg-green-100 text-green-700"
                        : activity.status === "Pending"
                        ? "bg-yellow-100 text-yellow-700"
                        : "bg-red-100 text-red-700"
                    }`}
                  >
                    {activity.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RecentActivitiesTable;
