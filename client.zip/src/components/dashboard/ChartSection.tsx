import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const barData = [
  { name: "Jan", users: 400 },
  { name: "Feb", users: 300 },
  { name: "Mar", users: 500 },
  { name: "Apr", users: 600 },
  { name: "May", users: 700 },
];

const lineData = [
  { name: "Jan", revenue: 2400 },
  { name: "Feb", revenue: 2210 },
  { name: "Mar", revenue: 2290 },
  { name: "Apr", revenue: 2000 },
  { name: "May", revenue: 2780 },
];

const pieData = [
  { name: "Monthly", value: 60 },
  { name: "Quarterly", value: 25 },
  { name: "Yearly", value: 15 },
];

const COLORS = ["#00C6FF", "#0033A0", "#FFBB28"];

const ChartSection = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mt-8">
      {/* Bar Chart */}
      <div className="bg-white rounded-2xl p-4 shadow border">
        <h2 className="text-lg font-semibold mb-4">User Signups</h2>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={barData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="users" fill="#0033A0" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Line Chart */}
      <div className="bg-white rounded-2xl p-4 shadow border">
        <h2 className="text-lg font-semibold mb-4">Revenue Growth</h2>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={lineData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="revenue"
              stroke="#00C6FF"
              strokeWidth={3}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Pie Chart */}
      <div className="bg-white rounded-2xl p-4 shadow border">
        <h2 className="text-lg font-semibold mb-4">Subscription Types</h2>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              outerRadius={70}
              dataKey="value"
              label
            >
              {pieData.map((entry, index) => (
                <Cell key={index} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ChartSection;
