import { cn } from "../../lib/utils";

interface StatCardProps {
  icon: React.ReactNode;
  value: string;
  label: string;
  className?: string;
}

const StatCard = ({ icon, value, label, className }: StatCardProps) => {
  return (
    <div
      className={cn(
        "bg-white rounded-2xl p-4 shadow hover:shadow-md transition-all border-l-4",
        className
      )}
    >
      <div className="flex items-center gap-3 mb-2 text-blue-600">{icon}</div>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-sm text-gray-500">{label}</div>
    </div>
  );
};

export default StatCard;
