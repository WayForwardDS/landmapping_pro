type ButtonProps = {
  label: string;
  type?: 'button' | 'submit';
};

export const Button = ({ label, type = 'button' }: ButtonProps) => (
  <button
    type={type}
    className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition"
  >
    {label}
  </button>
);
