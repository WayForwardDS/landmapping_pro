interface CalculatorProps {
  time: string;
  rate: number;
  total: number;
  details: string;
}

export const ParkingCalculator = ({ time, rate, total, details }: CalculatorProps) => (
  <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-white rounded-xl shadow-lg px-6 py-4 text-sm w-[300px] z-10">
    <h2 className="text-lg font-bold text-center underline">Parking Calculator</h2>
    <div className="flex justify-between mt-4">
      <div>
        <p className="font-semibold">TIME</p>
        <p>{time}</p>
      </div>
      <div>
        <p className="font-semibold">RATE</p>
        <p>${rate}/hour</p>
      </div>
      <div>
        <p className="font-semibold">TOTAL</p>
        <p>${total}</p>
      </div>
    </div>
    <div className="mt-4">
      <p className="text-sm font-semibold">Parking Details:</p>
      <p>{details}</p>
      <button className="w-full py-1 mt-2 text-white bg-gray-700 rounded">Print Ticket</button>
    </div>
  </div>
);
