import { useRef, useState } from "react";

interface ImageUploaderProps {
  onUpload: (file: File) => void;
}

const ImageUploader = ({ onUpload }: ImageUploaderProps) => {
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
      onUpload(file);
    }
  };

  return (
    <div className="border border-dashed rounded-xl p-4 text-center cursor-pointer hover:border-blue-500 transition">
      <input
        type="file"
        accept="image/*"
        ref={fileRef}
        onChange={handleFileChange}
        className="hidden"
      />
      {preview ? (
        <img
          src={preview}
          alt="Preview"
          className="mx-auto w-full max-w-sm rounded-lg object-cover"
        />
      ) : (
        <div
          onClick={() => fileRef.current?.click()}
          className="text-gray-500"
        >
          <p className="text-sm">Click to upload image</p>
          <p className="text-xs">Supported: JPG, PNG</p>
        </div>
      )}
    </div>
  );
};

export default ImageUploader;
