import { Bell, Search } from 'lucide-react';

const Topbar = () => {
  return (
    <div className="bg-white border-b px-6 py-3 flex justify-between items-center">
      <div className="relative w-1/3">
        <input
          type="text"
          placeholder="Search..."
          className="w-full px-4 py-2 border rounded-lg pl-10 text-sm"
        />
        <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
      </div>
      <div className="flex items-center gap-4">
        <Bell className="text-gray-500" size={20} />
        <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm">
          A
        </div>
      </div>
    </div>
  );
};

export default Topbar;
