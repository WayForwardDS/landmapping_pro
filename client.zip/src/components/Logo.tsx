// import logo from '@/assets/logo.svg'; // You can replace with your car icon

// export const Logo = () => (
//   <img src={logo} alt="App Logo" className="h-12" />
// );
