import { NavLink } from 'react-router-dom';
import {
  Home,
  Users,
  Settings,
  BarChart2,
  PlusSquare,
  Building2,
  CreditCard,
  MapPin,
  Eye,
  ScanLine,
  BadgeDollarSign,
} from 'lucide-react';

const navItems = [
  { name: 'Dashboard', icon: <Home size={18} />, path: '/dashboard' },
  { name: 'Add Space', icon: <PlusSquare size={18} />, path: '/add-space' },
  { name: 'Facilities', icon: <Building2 size={18} />, path: '/facilities' },
  { name: 'Transactions', icon: <CreditCard size={18} />, path: '/transactions' },
  { name: 'Map View', icon: <MapPin size={18} />, path: '/map-view' },
  { name: 'Live Parking', icon: <Eye size={18} />, path: '/live-parking' },
  { name: 'Scanner', icon: <ScanLine size={18} />, path: '/scanner' },
  { name: 'Subscription', icon: <BadgeDollarSign size={18} />, path: '/subscription' },
  { name: 'Users', icon: <Users size={18} />, path: '/users' },
  { name: 'Reports', icon: <BarChart2 size={18} />, path: '/reports' },
  { name: 'Settings', icon: <Settings size={18} />, path: '/settings' },
];

const Sidebar = () => {
  return (
    <aside className="flex flex-col w-64 bg-white shadow-md">
      {/* Optionally add logo */}
      {/* <div className="px-6 py-4 border-b">
        <Logo />
      </div> */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navItems.map((item) => (
          <NavLink
            to={item.path}
            key={item.name}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-lg font-medium text-sm ${
                isActive
                  ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white'
                  : 'text-gray-700 hover:bg-gray-100'
              }`
            }
          >
            {item.icon}
            {item.name}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
