type SlotStatus = 'available' | 'occupied' | 'selected';

interface ParkingSlotProps {
  top: string;
  left: string;
  status: SlotStatus;
  onClick?: () => void;
}

const getColor = (status: SlotStatus) => {
  switch (status) {
    case 'available':
      return 'border-green-500';
    case 'occupied':
      return 'border-red-500';
    case 'selected':
      return 'bg-green-500 border-white';
  }
};

export const ParkingSlot = ({ top, left, status, onClick }: ParkingSlotProps) => {
  return (
    <div
      className={`absolute w-8 h-14 border-2 rounded flex items-center justify-center text-white cursor-pointer ${getColor(status)}`}
      style={{ top, left }}
      onClick={onClick}
    >
      +
    </div>
  );
};
