import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import SignIn from "./pages/auth/SignIn";
import ForgotPassword from "./pages/auth/ForgotPassword";
import DashboardLayout from "./components/DashboardLayout";
import { Home } from "lucide-react";
import AddSpace from "./pages/dashboard/AddSpace";
import Dashboard from "./pages/dashboard/Dashboard";
import SignUp from "./pages/auth/SignUp";
import Facilities from "./pages/dashboard/Facilities";
import Transactions from "./pages/dashboard/Transactions";
import MapView from "./pages/dashboard/MapView";
import LiveParking from "./pages/dashboard/LiveParking";
import Scanner from "./pages/dashboard/Scanner";
import Subscription from "./pages/dashboard/Subscription";
// import LiveParking from "./pages/dashboard/LiveParking";


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/add-space" element={<AddSpace />} />
        <Route path="/facilities" element={<Facilities />} />
        <Route path="/transactions" element={<Transactions />} />
        <Route path="/map-view" element={<MapView />} />
        <Route path="/live-parking" element={<LiveParking />} />
        <Route path="/scanner" element={<Scanner />} />
        <Route path="/subscription" element={<Subscription />} />
        <Route path="/" element={<SignIn />} />
      </Routes>
    </Router>
  );
}



export default App;
